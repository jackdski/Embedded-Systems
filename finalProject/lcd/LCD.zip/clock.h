/*
 * clock.h
 *
 *  Created on: Dec 7, 2017
 *      Author: Stefan
 */

#ifndef CLOCK_H_
#define CLOCK_H_


#include "msp.h"


void configure_SystemClock();

void Delay0();
void Delay1();
void Delay2();
void Delay3();
void Delay4();
void Delay5();


#endif /* CLOCK_H_ */




